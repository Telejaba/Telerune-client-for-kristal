# KristalAchievements
Yooooooooooooooooooooo

So this is where a roughtdocumentation will be made, but im a bit busy rn :/
