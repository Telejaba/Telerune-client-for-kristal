Kristal Widescreen
-----------------------------------------------------------------
it makes your kristal wide. thats all

WidescreenLib:toWideScreen() sets it to the widescreen,
WidescreenLib:toInitScreen() sets it back. You cal also do that from the DarkConfigMenu

WidescreenLib:inInitRatio(x, y) returns true if x is in the original DR ratio, and false if it's outside of that. y is optional

i was going to add moreparty support but too many hooks. it still works though
and, magical glass support