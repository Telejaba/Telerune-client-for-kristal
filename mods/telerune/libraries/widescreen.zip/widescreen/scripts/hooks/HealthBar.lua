local HealthBar, super = Class("HealthBar")

function HealthBar:init()
    super.super.init(self, 0, -80)

    self.layer = 1 -- TODO

    self.parallax_x = 0
    self.parallax_y = 0

    self.animation_done = false
    self.animation_timer = 0
    self.animate_out = false

    self.action_boxes = {}

    for index, chara in ipairs(Game.party) do
        local x_pos = (index - 1) * 213

        if WidescreenLib.widescreen and #Game.party == 4 then
            x_pos = (index - 1) * 213 - SCREEN_WIDTH_DIST + 1
        elseif #Game.party == 2 then
            if index == 1 then
                x_pos = 108
            else
                x_pos = 322
            end
        elseif #Game.party == 1 then
            x_pos = 213
        end

        local action_box = OverworldActionBox(x_pos, 0, index, chara)
        self:addChild(action_box)
        table.insert(self.action_boxes, action_box)
        chara:onActionBox(action_box, true)
    end

    self.auto_hide_timer = 0
end

function HealthBar:draw()
    -- Draw the black background
    Draw.setColor(PALETTE["world_fill"])
    love.graphics.rectangle("fill", 0 - self.x, 2, SCREEN_WIDTH + 1, 61)

    super.super.draw(self)
end

return HealthBar